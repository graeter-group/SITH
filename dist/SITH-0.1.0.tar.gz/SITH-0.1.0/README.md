# SITH
redesign and simplification of JEDI approach

Sectioning/Subdivision/Sundering of
Internal
Transformation/Tension
Heat

Stress
Induced
Traversal of
Hessian

Stress energy
Investigated via
Traversal of
Hessian 

Stress
Interspersed
Traversal of
Hessian

Scattering/Sharing/Sectioning of
Internal
Tension based on
Hessian

Strain
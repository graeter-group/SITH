# SITH
repo for refactorization of JEDI code

Sectioning/Subdivision/Sundering of
Internal
Transformation/Tension
Heat

Stress
Induced
Traversal of
Hessian

Stress energy
Investigated by
Traversal of
Hessian 
